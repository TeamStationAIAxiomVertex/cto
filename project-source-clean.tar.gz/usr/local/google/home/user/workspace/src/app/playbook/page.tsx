
import { redirect } from 'next/navigation';

export default function PlaybookPage() {
    redirect('/playbook/hub');
}
