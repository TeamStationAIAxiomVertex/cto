export * from './accordion.client';
